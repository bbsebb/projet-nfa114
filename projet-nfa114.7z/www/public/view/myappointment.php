
<h2><?= $this->bind['title']?></h2>
<h3>Mes rendez-vous</h3>
<?= $this->bind['success'] ?>
<?= $this->bind['table']?>