<h2><?= $this->bind['title']?></h2>
<p class="error"><?= $this->bind['errorMessage'] ?></p>