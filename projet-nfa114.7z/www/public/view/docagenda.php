<h2><?= $this->bind['title']?></h2>
<?= $this->bind['table']?>