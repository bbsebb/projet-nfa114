<h2><?= $this->bind['title']?></h2>
<h3>Les docteurs du cabinet : </h3>
<?= $this->bind['table_doc']?>
<h3>Les horaires du cabinet : </h3>
<?= $this->bind['table_open']?>
