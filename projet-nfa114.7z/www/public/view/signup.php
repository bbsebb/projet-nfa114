<h2><?= $this->bind['title']?></h2>
<div id="container-page" >

<?= $this->bind['errorMessage']??"" ?>
<?= $this->bind['form'] ?>
</div>