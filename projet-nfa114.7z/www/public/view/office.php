<h2><?= $this->bind['title']?></h2>
<?php

use App\utils\forms\Form;
use App\utils\validators\ValidatorFactory;

require '../vendor/autoload.php';




?>