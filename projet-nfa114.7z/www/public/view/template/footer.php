<div id="footer">
<hr>
<p>Projet NFA114 - Semestre 2 Année 2022</p>
<p>auteur : <a href="mailto:sebastien.burckhardt@gmail.com">Sebastien Burckhardt</a></p>
</div>