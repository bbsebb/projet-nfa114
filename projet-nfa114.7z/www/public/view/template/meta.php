<link rel="stylesheet" href="/view/css/styles.css">
<script type="text/javascript" src="../view/js/nav-bar.js" defer></script>
<script type="text/javascript" src="../view/js/success.js" defer></script>
<script type="text/javascript" src="../view/js/agenda.js" defer></script>
