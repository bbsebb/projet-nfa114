<h2><?= $this->bind['title']?></h2>
<h3>Ajouter un medecin</h3>
<?= $this->bind['errorMessage'] ?>
<?= $this->bind['form'] ?>
<h3>Liste des médecins</h3>
<?= $this->bind['success'] ?>
<?= $this->bind['table'] ?>