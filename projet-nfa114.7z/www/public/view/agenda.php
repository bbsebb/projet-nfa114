<h2><?= $this->bind['title']?></h2>
<?= $this->bind['form']?>
<div id="timeslots">
<?= $this->bind['timeSlot']?>
</div>

