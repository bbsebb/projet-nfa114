<?php

namespace App\controllers;

abstract class AbstractController {
    
}